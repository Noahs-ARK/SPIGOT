#!/bin/sh

set -eu

touch NEWS
autoreconf -i
